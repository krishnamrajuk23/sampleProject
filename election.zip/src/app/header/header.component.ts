import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { RegistrationService } from "../shared/services/registration.service";
import { RegisterValidationService } from "../shared/services/register-validation.service";

@Component({
  selector: "app-header",
  templateUrl: "./header.component.html",
  encapsulation: ViewEncapsulation.None,
  styleUrls: ["./header.component.scss"]
})
export class HeaderComponent implements OnInit {
  showMenu = true;
  isLogin = true;
  isRegister = false;
  registerForm: FormGroup;
  loginForm: FormGroup;
  submitted = false;
  loginStatus = false;
  validationMessage: any;

  constructor(
    private modalService: NgbModal,
    private fb: FormBuilder,
    private router: Router,
    private registerService: RegistrationService,
    private registerValidationService: RegisterValidationService
  ) {}

  ngOnInit() {
    this.registrationForm();
    this.loginformDetails();
  }

  openVerticallyCentered(content) {
    this.modalService.open(content, { centered: true });
  }

  onLogin(loginForm, modal) {
    this.loginStatus = true;
    // stop here if form is invalid
    if (this.loginForm.invalid) {
      return;
    }
    modal.close();
    this.router.navigate(["editor"]);
    console.log("success", this.loginForm.value);
  }

  loginformDetails() {
    this.loginForm = this.fb.group({
      emailId: ["", [Validators.required, Validators.email]],
      password: [""]
    });
  }

  registrationForm() {
    this.registerForm = this.fb.group({
      name: ["", Validators.required],
      emailId: ["", [Validators.required, Validators.email]],
      phoneNum: ["", Validators.required],
      password: ["", Validators.required],
      userid: ["", Validators.required]
    });
  }

  onSubmit(event) {
    this.submitted = true;
    // stop here if form is invalid
    if (this.registerForm.invalid) {
      return;
    }
    this.registerService.addRegistrationDetails(event.value);
  }

  //register validation service for each input field
  onBlurMethod(event) {
    const fieldData = event.currentTarget;
    this.registerValidationService
      .getValidationFormFields(fieldData.id, fieldData.value)
      .subscribe(response => {
        this.validationMessage = response;
      });
  }
}
