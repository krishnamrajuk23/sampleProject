import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import {Router} from "@angular/router";

@Component({
  selector: 'app-add-post',
  templateUrl: './add-post.component.html',
  styleUrls: ['./add-post.component.scss']
})
export class AddPostComponent implements OnInit {

  editorForm: FormGroup;
  constructor(private fb: FormBuilder, private router:Router) { }

  ngOnInit() {
    this.editorFormDetails();
  }

  editorFormDetails(){
    this.editorForm = this.fb.group({
      title:[''],
      description:[''],
      location:[''],
      link:[''],
      date:['']
    })
  }

  onSubmit(){
    this.router.navigate(['editor']);
  }

  addSavePost(){
    this.router.navigate(['editor']);
  }

  addPost(){

  }

}
