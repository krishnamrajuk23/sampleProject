import { Component, OnInit } from '@angular/core';
import {AdminService} from "../shared/services/admin.service";

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})
export class AdminComponent implements OnInit {
  newsposts:object;
  constructor(private adminService:AdminService) { }

  ngOnInit() {
    this.adminService.getAdminReviewNews().subscribe(response=>{
        this.newsposts = response;
    });
  }

  approve(data){
    this.adminService.updateAdminReviewNews(data);
  }
}
