import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { HOST_URL } from "../config/host.config";

@Injectable({
  providedIn: "root"
})
export class UserService {
  constructor(private http: HttpClient) {}

  addToDraftNews(data) {
    return this.http.post(HOST_URL + "/user/draft-news", data);
  }

  updateDraftNews(data) {
    return this.http.put(HOST_URL + "/user/draft-news", data);
  }

  getDraftNewsById(editorId) {
    return this.http.get(HOST_URL + "/user/draft-news/" + editorId);
  }

  postToPublisher(data) {
    return this.http.post(HOST_URL + "/user/publish-news", data);
  }

  getPublisherNewById(editorId) {
    return this.http.get(HOST_URL + "/user/publish-news/" + editorId);
  }
}
