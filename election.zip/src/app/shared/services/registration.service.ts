import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { HOST_URL } from "../config/host.config";

@Injectable({
  providedIn: "root"
})
export class RegistrationService {
  constructor(private http: HttpClient) {}

  addRegistrationDetails(data) {
    return this.http.get(HOST_URL + "/signup");
  }
}
