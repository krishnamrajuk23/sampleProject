import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { HOST_URL } from "../config/host.config";

const ADMIN_URL: string = "/admin/review-news";

@Injectable({
  providedIn: "root"
})
export class AdminService {
  constructor(private http: HttpClient) {}

  getAdminReviewNews() {
    return this.http.get(HOST_URL + ADMIN_URL);
  }

  updateAdminReviewNews(data) {
    return this.http.put(HOST_URL + ADMIN_URL, data);
  }
}
