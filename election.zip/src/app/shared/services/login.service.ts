import { Injectable } from "@angular/core";
import { HOST_URL } from "../config/host.config";

@Injectable({
  providedIn: "root"
})
export class LoginService {
  constructor(private http: HttpClient) {}

  loginStatus(data) {
    return this.http.post(HOST_URL + "login", data);
  }
}
