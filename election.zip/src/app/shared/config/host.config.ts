export const HOST_URL: string = "http://localhost:8080/api-ln";
