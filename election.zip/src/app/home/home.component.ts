import { Component, OnInit } from '@angular/core';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  newsData = [
    {
      "id": 1,
      "title": "My News",
      "description": "This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.",
      "refLink": "http://mendozafoodcourt.com/market",
      "location": [],
      "newsDate": "10/15/155",
      "likesCount": 6,
      "dislikesCount": 8,
      "publishedBy": "Raju"
    },
    {
      "id": 1,
      "title": "My News",
      "description": "This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.",
      "refLink": "http://mendozafoodcourt.com/market",
      "location": [],
      "newsDate": "",
      "likesCount": 111,
      "dislikesCount": 5,
      "publishedBy": "Raju"
    },
    {
      "id": 1,
      "title": "My News",
      "description": "This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.",
      "refLink": "http://mendozafoodcourt.com/market",
      "location": [],
      "newsDate": "",
      "likesCount": 10,
      "dislikesCount": 150,
      "publishedBy": "Raju"
    }
  ];
  constructor(private modalService: NgbModal) { }

  ngOnInit() {
  }

}
